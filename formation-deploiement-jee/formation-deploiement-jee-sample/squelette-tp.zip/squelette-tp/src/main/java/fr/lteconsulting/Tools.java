package fr.lteconsulting;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

/*
    Utilisez cette classe à votre convenance, vous pouvez même la supprimer !
*/
public class Tools {
}

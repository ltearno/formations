package fr.lteconsulting;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

public class Tools {
}

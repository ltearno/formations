package fr.lteconsulting.training.marvels.dao;

import fr.lteconsulting.training.marvels.Marvel;

import javax.annotation.PostConstruct;
import javax.ejb.Singleton;
import java.util.ArrayList;
import java.util.List;

@Singleton
public class MarvelsDataStore
{
	private List<Marvel> marvels;

	@PostConstruct
	void onInit()
	{
		marvels = new ArrayList<>();
		marvels.add( new Marvel( "sajahgkhgkjhg", "Bruce" ) );
		marvels.add( new Marvel( "lkjhsloioa", "Peter" ) );
		marvels.add( new Marvel( "iaud-h", "Sam" ) );
	}

	public List<Marvel> getAll()
	{
		return marvels;
	}
}

package fr.lteconsulting.training.marvels.ws;

import fr.lteconsulting.training.marvels.Marvel;
import fr.lteconsulting.training.marvels.dao.MarvelsDataStore;

import javax.ejb.EJB;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.util.List;

@Path( "/marvels" )
public class MarvelsWS
{
	@EJB
	MarvelsDataStore store;

	@GET
	@Produces( MediaType.APPLICATION_JSON )
	public List<Marvel> getAll()
	{
		return store.getAll();
	}
}
